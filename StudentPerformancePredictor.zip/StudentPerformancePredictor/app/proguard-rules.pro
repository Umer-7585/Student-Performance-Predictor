# Add project specific ProGuard rules here.
-keep class com.github.mikephil.charting.** { *; }
-keep class okhttp3.** { *; }
-keep class org.json.** { *; }
