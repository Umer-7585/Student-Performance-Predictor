package com.student.predictor;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class LockedActivity extends AppCompatActivity {

    private TextView tvTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locked);

        tvTimer = findViewById(R.id.tvTimer);
        startCountdown();
    }

    private void startCountdown() {
        long remainingMillis = LockManager.getRemainingTime(this);
        
        new CountDownTimer(remainingMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int hours = (int) (millisUntilFinished / 3600000);
                int minutes = (int) (millisUntilFinished % 3600000) / 60000;
                int seconds = (int) (millisUntilFinished % 60000) / 1000;
                
                String timeLeft = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
                tvTimer.setText(timeLeft);
            }

            @Override
            public void onFinish() {
                finish();
            }
        }.start();
    }

    @Override
    public void onBackPressed() {
        // Prevent going back
    }
}
