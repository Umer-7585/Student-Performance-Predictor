package com.student.predictor;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.github.mikephil.charting.charts.RadarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.material.appbar.MaterialToolbar;
import okhttp3.*;
import org.json.*;
import java.io.IOException;
import java.util.*;

public class ResultActivity extends AppCompatActivity {

    private int study, attendance, assignments, participation, sleep, prevGrade, stress;
    private TextView tvScore, tvGradeLetter, tvGradeLabel, tvAiAnalysis;
    private ProgressBar pbScore, pbAiLoading;
    private LinearLayout llWeaknesses;
    private RadarChart radarChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // Get data from intent
        Bundle b = getIntent().getExtras();
        if (b != null) {
            study        = b.getInt("study");
            attendance   = b.getInt("attendance");
            assignments  = b.getInt("assignments");
            participation= b.getInt("participation");
            sleep        = b.getInt("sleep");
            prevGrade    = b.getInt("prevGrade");
            stress       = b.getInt("stress");
        }

        tvScore       = findViewById(R.id.tvScore);
        tvGradeLetter = findViewById(R.id.tvGradeLetter);
        tvGradeLabel  = findViewById(R.id.tvGradeLabel);
        tvAiAnalysis  = findViewById(R.id.tvAiAnalysis);
        pbScore       = findViewById(R.id.pbScore);
        pbAiLoading   = findViewById(R.id.pbAiLoading);
        llWeaknesses  = findViewById(R.id.llWeaknesses);
        radarChart    = findViewById(R.id.radarChart);

        int score = predictScore();
        displayResult(score);
        displayWeaknesses(score);
        
        // Feature 1 Logic
        handlePerformanceActions(score);

        setupRadarChart();
        fetchAiAnalysis(score);
    }

    private void handlePerformanceActions(int score) {
        if (score < 60) {
            String message = score < 50 ? 
                "Critical: Your performance is very low. App will be locked for 2 minutes." :
                "Warning: Your performance is below 60%. Check recommendations.";
            
            NotificationHelper.showWarningNotification(this, "Performance Alert", message);
            
            if (score < 50) {
                LockManager.lockApp(this);
                new Handler().postDelayed(() -> {
                    Intent intent = new Intent(ResultActivity.this, LockedActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }, 3000);
            }
        }
    }

    private int predictScore() {
        double raw = study * 2.5
                + attendance * 0.25
                + assignments * 0.20
                + participation * 0.10
                + sleep * 1.5
                + prevGrade * 0.30
                - stress * 0.08;
        return (int) Math.min(100, Math.max(0, Math.round(raw)));
    }

    private int[] gradeColor(int score) {
        if (score >= 90) return new int[]{0xFF10B981, 0xFF065F46}; // green
        if (score >= 80) return new int[]{0xFF00D4FF, 0xFF0369A1}; // cyan
        if (score >= 70) return new int[]{0xFF3B82F6, 0xFF1D4ED8}; // blue
        if (score >= 60) return new int[]{0xFFF59E0B, 0xFF92400E}; // amber
        if (score >= 50) return new int[]{0xFFF97316, 0xFF9A3412}; // orange
        return new int[]{0xFFEF4444, 0xFF991B1B}; // red
    }

    private String gradeLetter(int score) {
        if (score >= 90) return "A+";
        if (score >= 80) return "A";
        if (score >= 70) return "B";
        if (score >= 60) return "C";
        if (score >= 50) return "D";
        return "F";
    }

    private String gradeLabel(int score) {
        if (score >= 90) return "Excellent Performance";
        if (score >= 80) return "Very Good Performance";
        if (score >= 70) return "Good Performance";
        if (score >= 60) return "Average Performance";
        if (score >= 50) return "Below Average";
        return "Needs Immediate Help";
    }

    private void displayResult(int score) {
        tvScore.setText(score + "%");
        tvGradeLetter.setText("Grade: " + gradeLetter(score));
        tvGradeLabel.setText(gradeLabel(score));
        pbScore.setProgress(score);

        int[] colors = gradeColor(score);
        tvScore.setTextColor(colors[0]);
        tvGradeLetter.setTextColor(colors[0]);

        CardView cardGrade = findViewById(R.id.cardGrade);
        cardGrade.setCardBackgroundColor(colors[1]);
    }

    private void displayWeaknesses(int score) {
        llWeaknesses.removeAllViews();
        List<String[]> list = new ArrayList<>();

        if (attendance < 75)
            list.add(new String[]{"⚠ Low Attendance",
                    attendance + "% — Minimum 75% required. Missing classes creates knowledge gaps.", "HIGH"});
        if (study < 3)
            list.add(new String[]{"⚠ Insufficient Study Time",
                    "Only " + study + "h/day. Aim for at least 3-4 hours daily.", "HIGH"});
        if (assignments < 60)
            list.add(new String[]{"⚠ Poor Assignment Completion",
                    assignments + "% — Assignments reinforce learning. Try to reach 80%+.", "HIGH"});
        if (stress > 70)
            list.add(new String[]{"⚠ High Stress Level",
                    stress + "% — High stress impairs memory and cognitive performance.", "MEDIUM"});
        if (sleep < 6)
            list.add(new String[]{"⚠ Sleep Deprivation",
                    "Only " + sleep + "h sleep. Brain needs 7-8h to consolidate memory.", "MEDIUM"});
        if (participation < 50)
            list.add(new String[]{"⚠ Low Class Participation",
                    participation + "% — Active engagement boosts retention by 40%.", "MEDIUM"});
        if (prevGrade < 55)
            list.add(new String[]{"⚠ Weak Foundation",
                    "Previous grade " + prevGrade + "% — Knowledge gaps will compound over time.", "LOW"});

        if (list.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("✅ No critical weaknesses detected! Keep it up!");
            tv.setTextColor(0xFF10B981);
            tv.setTextSize(15);
            tv.setPadding(16, 16, 16, 16);
            llWeaknesses.addView(tv);
            return;
        }

        for (String[] w : list) {
            View card = getLayoutInflater().inflate(R.layout.item_weakness, llWeaknesses, false);
            ((TextView) card.findViewById(R.id.tvWeaknessTitle)).setText(w[0]);
            ((TextView) card.findViewById(R.id.tvWeaknessDetail)).setText(w[1]);
            TextView tvSev = card.findViewById(R.id.tvSeverity);
            tvSev.setText(w[2]);
            int sevColor = w[2].equals("HIGH") ? 0xFFEF4444 : w[2].equals("MEDIUM") ? 0xFFF59E0B : 0xFF10B981;
            tvSev.setTextColor(sevColor);
            tvSev.setBackgroundColor(sevColor & 0x22FFFFFF);
            llWeaknesses.addView(card);
        }
    }

    private void setupRadarChart() {
        List<RadarEntry> entries = new ArrayList<>();
        entries.add(new RadarEntry(Math.min(100, study * 10)));
        entries.add(new RadarEntry(attendance));
        entries.add(new RadarEntry(assignments));
        entries.add(new RadarEntry(participation));
        entries.add(new RadarEntry(Math.min(100, sleep * 12)));
        entries.add(new RadarEntry(prevGrade));

        RadarDataSet dataSet = new RadarDataSet(entries, "Student Profile");
        dataSet.setColor(Color.parseColor("#00D4FF"));
        dataSet.setFillColor(Color.parseColor("#00D4FF"));
        dataSet.setDrawFilled(true);
        dataSet.setFillAlpha(80);
        dataSet.setLineWidth(2f);
        dataSet.setDrawHighlightCircleEnabled(true);

        RadarData data = new RadarData(dataSet);
        data.setValueTextColor(Color.WHITE);
        data.setValueTextSize(8f);

        radarChart.setData(data);
        radarChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(
                new String[]{"Study", "Attend", "Assign", "Particip", "Sleep", "Prev"}));
        radarChart.getXAxis().setTextColor(Color.parseColor("#94A3B8"));
        radarChart.getYAxis().setTextColor(Color.parseColor("#64748B"));
        radarChart.getYAxis().setAxisMinimum(0f);
        radarChart.getYAxis().setAxisMaximum(100f);
        radarChart.getYAxis().setLabelCount(4);
        radarChart.getLegend().setEnabled(false);
        radarChart.getDescription().setEnabled(false);
        radarChart.setBackgroundColor(Color.parseColor("#111827"));
        radarChart.setWebColor(Color.parseColor("#1E2D45"));
        radarChart.setWebColorInner(Color.parseColor("#1E2D45"));
        radarChart.setWebAlpha(100);
        radarChart.invalidate();
    }

    private void fetchAiAnalysis(int score) {
        pbAiLoading.setVisibility(View.VISIBLE);
        tvAiAnalysis.setVisibility(View.GONE);

        String prompt = "You are an expert academic advisor AI. Analyze this student's performance data and provide a concise, actionable report in 5-7 lines:\n\n"
                + "Student Data:\n"
                + "- Study Hours/Day: " + study + "h\n"
                + "- Attendance: " + attendance + "%\n"
                + "- Assignment Completion: " + assignments + "%\n"
                + "- Class Participation: " + participation + "%\n"
                + "- Sleep Hours: " + sleep + "h\n"
                + "- Previous Grade: " + prevGrade + "%\n"
                + "- Stress Level: " + stress + "%\n"
                + "- Predicted Grade: " + score + "% (" + gradeLetter(score) + " - " + gradeLabel(score) + ")\n\n"
                + "Give a personalized analysis with:\n"
                + "1. Overall performance summary (1-2 lines)\n"
                + "2. Top 2-3 specific improvement tips tailored to their weak areas\n"
                + "3. An encouraging closing statement\n\n"
                + "Keep tone professional yet motivating. Respond in plain text, no markdown symbols.";

        JSONObject body = new JSONObject();
        try {
            JSONArray messages = new JSONArray();
            JSONObject msg = new JSONObject();
            msg.put("role", "user");
            msg.put("content", prompt);
            messages.put(msg);
            body.put("model", "claude-sonnet-4-20250514");
            body.put("max_tokens", 1000);
            body.put("messages", messages);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("Content-Type", "application/json")
                .addHeader("anthropic-version", "2023-06-01")
                .post(RequestBody.create(body.toString(), MediaType.parse("application/json")))
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    pbAiLoading.setVisibility(View.GONE);
                    tvAiAnalysis.setVisibility(View.VISIBLE);
                    tvAiAnalysis.setText("AI analysis unavailable. Check your internet connection and try again.");
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseBody = response.body().string();
                runOnUiThread(() -> {
                    pbAiLoading.setVisibility(View.GONE);
                    tvAiAnalysis.setVisibility(View.VISIBLE);
                    try {
                        JSONObject json = new JSONObject(responseBody);
                        JSONArray content = json.getJSONArray("content");
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < content.length(); i++) {
                            JSONObject block = content.getJSONObject(i);
                            if ("text".equals(block.getString("type"))) {
                                sb.append(block.getString("text"));
                            }
                        }
                        tvAiAnalysis.setText(sb.toString());
                    } catch (JSONException e) {
                        tvAiAnalysis.setText("Could not parse AI response. Please try again.");
                    }
                });
            }
        });
    }
}
