package com.student.predictor;

import android.content.Context;
import android.content.SharedPreferences;

public class LockManager {
    private static final String PREF_NAME = "AppLockPrefs";
    private static final String KEY_LOCK_TIME = "lock_until";
    private static final long LOCK_DURATION_MS = 120000; // 2 minutes

    public static void lockApp(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        long lockUntil = System.currentTimeMillis() + LOCK_DURATION_MS;
        prefs.edit().putLong(KEY_LOCK_TIME, lockUntil).apply();
    }

    public static boolean isLocked(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        long lockUntil = prefs.getLong(KEY_LOCK_TIME, 0);
        return System.currentTimeMillis() < lockUntil;
    }

    public static long getRemainingTime(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        long lockUntil = prefs.getLong(KEY_LOCK_TIME, 0);
        return Math.max(0, lockUntil - System.currentTimeMillis());
    }
}
