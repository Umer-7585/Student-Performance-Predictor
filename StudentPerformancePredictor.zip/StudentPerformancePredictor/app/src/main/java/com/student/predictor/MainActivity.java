package com.student.predictor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;

public class MainActivity extends AppCompatActivity {

    private SeekBar sbStudyHours, sbAttendance, sbAssignments,
            sbParticipation, sbSleep, sbPrevGrade, sbStress;

    private TextView tvStudyVal, tvAttendVal, tvAssignVal,
            tvPartVal, tvSleepVal, tvPrevVal, tvStressVal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Feature 1: Lock Check
        if (LockManager.isLocked(this)) {
            startActivity(new Intent(this, LockedActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // SeekBars
        sbStudyHours   = findViewById(R.id.sbStudyHours);
        sbAttendance   = findViewById(R.id.sbAttendance);
        sbAssignments  = findViewById(R.id.sbAssignments);
        sbParticipation= findViewById(R.id.sbParticipation);
        sbSleep        = findViewById(R.id.sbSleep);
        sbPrevGrade    = findViewById(R.id.sbPrevGrade);
        sbStress       = findViewById(R.id.sbStress);

        // Value TextViews
        tvStudyVal  = findViewById(R.id.tvStudyVal);
        tvAttendVal = findViewById(R.id.tvAttendVal);
        tvAssignVal = findViewById(R.id.tvAssignVal);
        tvPartVal   = findViewById(R.id.tvPartVal);
        tvSleepVal  = findViewById(R.id.tvSleepVal);
        tvPrevVal   = findViewById(R.id.tvPrevVal);
        tvStressVal = findViewById(R.id.tvStressVal);

        // Defaults
        sbStudyHours.setMax(12);   sbStudyHours.setProgress(4);
        sbAttendance.setMax(100);  sbAttendance.setProgress(75);
        sbAssignments.setMax(100); sbAssignments.setProgress(70);
        sbParticipation.setMax(100); sbParticipation.setProgress(60);
        sbSleep.setMax(12);        sbSleep.setProgress(7);
        sbPrevGrade.setMax(100);   sbPrevGrade.setProgress(65);
        sbStress.setMax(100);      sbStress.setProgress(50);

        updateAllLabels();
        attachListeners();

        Button btnAnalyze = findViewById(R.id.btnAnalyze);
        btnAnalyze.setOnClickListener(v -> {
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("study",       sbStudyHours.getProgress());
            intent.putExtra("attendance",  sbAttendance.getProgress());
            intent.putExtra("assignments", sbAssignments.getProgress());
            intent.putExtra("participation", sbParticipation.getProgress());
            intent.putExtra("sleep",       sbSleep.getProgress());
            intent.putExtra("prevGrade",   sbPrevGrade.getProgress());
            intent.putExtra("stress",      sbStress.getProgress());
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Feature 1: Lock Check on Resume
        if (LockManager.isLocked(this)) {
            startActivity(new Intent(this, LockedActivity.class));
            finish();
        }
    }

    private void attachListeners() {
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { updateAllLabels(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        };
        sbStudyHours.setOnSeekBarChangeListener(l);
        sbAttendance.setOnSeekBarChangeListener(l);
        sbAssignments.setOnSeekBarChangeListener(l);
        sbParticipation.setOnSeekBarChangeListener(l);
        sbSleep.setOnSeekBarChangeListener(l);
        sbPrevGrade.setOnSeekBarChangeListener(l);
        sbStress.setOnSeekBarChangeListener(l);
    }

    private void updateAllLabels() {
        tvStudyVal.setText(sbStudyHours.getProgress() + "h");
        tvAttendVal.setText(sbAttendance.getProgress() + "%");
        tvAssignVal.setText(sbAssignments.getProgress() + "%");
        tvPartVal.setText(sbParticipation.getProgress() + "%");
        tvSleepVal.setText(sbSleep.getProgress() + "h");
        tvPrevVal.setText(sbPrevGrade.getProgress() + "%");
        tvStressVal.setText(sbStress.getProgress() + "%");
    }
}
