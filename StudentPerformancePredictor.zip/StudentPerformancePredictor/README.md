# 📊 Student Performance Predictor - Android App

## 🚀 How to Run in Android Studio

### Step 1: Open Project
1. Android Studio open karein
2. **File → Open** click karein
3. Is folder ko select karein: `StudentPerformancePredictor`
4. **OK** click karein

### Step 2: API Key Add Karein
`ResultActivity.java` file open karein aur line dhundhein:
```java
.addHeader("anthropic-version", "2023-06-01")
```
Uske neeche yeh line add karein:
```java
.addHeader("x-api-key", "YOUR_ANTHROPIC_API_KEY_HERE")
```
Apni real Anthropic API key yahan paste karein.
API key milti hai: https://console.anthropic.com/

### Step 3: Gradle Sync
- Android Studio automatically Gradle sync karega
- Ya manually: **File → Sync Project with Gradle Files**

### Step 4: Run
- Emulator ya real device connect karein (Android 7.0+)
- **Run → Run 'app'** ya green ▶ button dabayein

---

## 📱 App Features
- **7 Input Sliders**: Study hours, attendance, assignments, participation, sleep, previous grade, stress
- **AI Grade Prediction**: Weighted formula se predicted score
- **Radar Chart**: Visual skill profile (MPAndroidChart)
- **Weakness Analysis**: Auto-detect karta hai weak areas with severity
- **AI Advisor**: Claude AI se personalized improvement tips

## 🔧 Requirements
- Android Studio Hedgehog (2023.1.1) ya newer
- JDK 8+
- Min SDK: Android 7.0 (API 24)
- Internet permission (AI analysis ke liye)

## 📦 Dependencies
- Material Design 3
- MPAndroidChart (Radar Chart)
- OkHttp3 (API calls)
- AndroidX CardView, AppCompat
